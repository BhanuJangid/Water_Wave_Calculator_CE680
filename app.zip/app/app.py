from flask import Flask, render_template, request
import math
import os
import matplotlib
matplotlib.use('Agg')  
import matplotlib.pyplot as plt
import numpy as np

app = Flask(__name__)
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/wavelength', methods=['GET', 'POST'])
def index():
    result = None
    iterations = None
    celerity = None
    plot_url = None
    wave_type = None

    if request.method == 'POST':
        g = 9.8  
        t = float(request.form['t'])
        d = float(request.form['d'])
        input_l = (9.81 * t**2)/(2*math.pi)
        cal_l = 0
        iteration_count = 0
        List_L = []
        List_it = []

        while True:
            cal_l = ((g * t**2) / (2 * math.pi)) * (math.tanh((2 * math.pi * d) / input_l))
            error = abs(cal_l - input_l)
            iteration_count += 1
            List_L.append(cal_l)
            List_it.append(iteration_count)

            if error < 0.001:
                break
            input_l = cal_l

        result = "{:.2f}".format(cal_l)
        iterations = iteration_count
        celerity = "{:.2f}".format(cal_l / t)

        # Plot the convergence of L over iterations
        plt.figure()
        plt.plot(List_it, List_L)
        plt.xlabel('Iterations')
        plt.ylabel('Calculated L')
        plt.title('Convergence of L over Iterations')

        plot_filename = os.path.join(app.root_path, 'static', 'plot.png')
        plt.savefig(plot_filename)
        plt.close()

        plot_url = 'static/plot.png'

        
        dl_ratio = d / cal_l

        if dl_ratio > 0.5:
            wave_type = "Deep Wave"
        elif dl_ratio > 0.05:
            wave_type = "Intermediate Wave"
        else:
            wave_type = "Shallow Wave"

    return render_template('index.html', result=result, iterations=iterations, 
                           celerity=celerity, plot_url=plot_url, wave_type=wave_type)

@app.route('/depth', methods=['GET', 'POST'])
def depth():
    result = None
    if request.method == 'POST':
        g = 9.8  
        t = float(request.form['t'])
        L = float(request.form['L'])

        if(2*math.pi*L/(9.81 * t**2)>1 or 2*math.pi*L/(g * t**2)< -1):
            result = "Math Error"

        else:
            result = (L/(2*math.pi))*math.atanh((2*math.pi*L/(g*t**2)))
            result = "{:.2f}".format(result)

    return render_template('depth.html', result=result)
  

@app.route('/vis', methods=['GET', 'POST'])
def vis():
  
    v = w = L = p = del_x = del_z = None
    displacement_plot_z_path = displacement_plot_path = pressure_plot_path = None
    a_x = a_z = acc_x_plot_path = acc_z_plot_path = None

    if request.method == 'POST':
     
        t = float(request.form['t'])
        d = float(request.form['d'])
        z = float(request.form['z'])
        h = float(request.form['h'])
        Q = float(request.form['Q'])
        Q = np.radians(Q)
        density = float(request.form['density'])
        g = 9.81
        gamma = density * g

        # Iterative calculation for wave length
        input_l = (9.81 * t**2) / (2 * math.pi)
        cal_l = 0
        while True:
            cal_l = ((g * t**2) / (2 * math.pi)) * (math.tanh((2 * math.pi * d) / input_l))
            error = abs(cal_l - input_l)
            if error < 0.001:
                break
            input_l = cal_l
        L = input_l
        k = 2 * math.pi / L
        sigma = 2 * math.pi / t

        
        v = ((math.pi * h) / t) * math.cosh(k * (d + z)) * math.cos(Q) / math.sinh(k * d)
        w = -1 * ((math.pi * h) / t) * math.sinh(k * (d + z)) * math.sin(Q) / math.sinh(k * d)

        a_x = -1 * ((2 * math.pi * math.pi * h) / (t * t)) * math.cosh(k * (d + z)) * math.cos(Q) / math.sinh(k * d)
        a_z = -1 * ((2 * math.pi * math.pi * h) / (t * t)) * math.sinh(k * (d + z)) * math.sin(Q) / math.sinh(k * d)

        D = h * math.cosh(k * (d + z)) / (2 * math.sinh(k * d))
        B = h * math.sinh(k * (d + z)) / (2 * math.sinh(k * d))

        del_x = D * math.cos(Q)
        del_z = B * math.sin(Q)

        # Displacement plots
        x = np.linspace(0, 2 * np.pi, 100)
        x_degrees = np.degrees(x)  # Convert the x values (radians) to degrees
        y = D * np.cos(x)

        plt.figure()
        plt.plot(x_degrees, y)
        plt.title('Displacement vs Phase Angle (ẟ(x) vs θ)')
        plt.xlabel('Phase Angle (θ in degrees)')  # Update the label to indicate degrees
        plt.ylabel('Displacement ẟ(x)')
        plt.grid(True)
        displacement_plot_path = os.path.join(app.root_path, 'static', 'displacement_plot.png')
        plt.savefig(displacement_plot_path)
        plt.close()


        y = B * np.sin(x)

        plt.figure()
        plt.plot(x_degrees, y)  # Use x_degrees for the x-axis
        plt.title('Displacement vs Phase Angle (ẟ(z) vs θ)')
        plt.xlabel('Phase Angle (θ in degrees)')  # Update the label
        plt.ylabel('Displacement ẟ(z)')
        plt.grid(True)
        displacement_plot_z_path = os.path.join(app.root_path, 'static', 'displacement_plot_z.png')
        plt.savefig(displacement_plot_z_path)
        plt.close()


        # Acceleration plots
        
        y = a_x * np.cos(x)

        plt.figure()
        plt.plot(np.degrees(x), y)  # Convert x to degrees
        plt.title('Acceleration vs Phase Angle (ax vs θ)')
        plt.xlabel('Phase Angle (θ in degrees)')
        plt.ylabel('Acceleration ax')
        plt.grid(True)
        acc_x_plot_path = os.path.join(app.root_path, 'static', 'acc_x_plot.png')
        plt.savefig(acc_x_plot_path)
        plt.close()

        # Acceleration in the z-direction
        y = a_z * np.sin(x)

        plt.figure()
        plt.plot(np.degrees(x), y)  # Convert x to degrees
        plt.title('Acceleration vs Phase Angle (az vs θ)')
        plt.xlabel('Phase Angle (θ in degrees)')
        plt.ylabel('Acceleration az')
        plt.grid(True)
        acc_z_plot_path = os.path.join(app.root_path, 'static', 'acc_z_plot.png')
        plt.savefig(acc_z_plot_path)
        plt.close()


        # Pressure plot
        p = gamma * h / 2 * np.cosh(k * (d + z)) * np.sin(Q) / np.cosh(k * d) - gamma * z
        Q_vals = np.linspace(0, 2 * np.pi, 100)
        p_vals = gamma * h / 2 * np.cosh(k * (d + z)) * np.sin(Q_vals) / np.cosh(k * d) - gamma * z

        plt.figure()
        plt.plot(np.degrees(Q_vals), p_vals)  # Convert Q_vals to degrees
        plt.title('Pressure vs Phase Angle (p(θ))')
        plt.xlabel('Phase Angle (θ in degrees)')  # Update the label
        plt.ylabel('Pressure p(θ)')
        plt.grid(True)
        pressure_plot_path = os.path.join(app.root_path, 'static', 'pressure_plot.png')
        plt.savefig(pressure_plot_path)
        plt.close()


    return render_template(
        'vis.html',
        L=L, 
        displacement_plot_z=displacement_plot_z_path, 
        displacement_plot=displacement_plot_path, 
        pressure_plot=pressure_plot_path, 
        v=v, 
        w=w, 
        p=p, 
        del_x=del_x, 
        del_z=del_z,
        a_x=a_x,
        a_z=a_z,
        acc_x_plot_path=acc_x_plot_path,
        acc_z_plot_path=acc_z_plot_path
    )

@app.route('/trans', methods=['GET', 'POST'])
def trans():
    result = None
    shoaling_plot_path = None
    height_plot_path = None
    refraction_plot_path = None

    if request.method == 'POST':
        try:
            t = float(request.form.get('t', 0))
            d = float(request.form.get('d', 0))
            h = float(request.form.get('h', 0))
            H0 = float(request.form.get('H0', 0))  # Deep water wave height
            alpha0 = float(request.form.get('alpha0', 0))  # Angle

            g = 9.81  # Gravitational constant
            input_l = (g * t**2) / (2 * math.pi)
            cal_l = 0
            while True:
                cal_l = ((g * t**2) / (2 * math.pi)) * (math.tanh((2 * math.pi * d) / input_l))
                error = abs(cal_l - input_l)
                if error < 0.001:
                    break
                input_l = cal_l
            L = input_l

            # Function to calculate shoaling coefficient
            def calculate_shoaling_cof(T, L, d):
                C0 = g * T / (2 * math.pi)
                k = 2 * math.pi / L
                n = 0.5 * (1 + 2 * k * d / np.sinh(2 * k * d))
                Ks = math.sqrt(C0 / (2 * n * C0))
                return Ks

            Ks = calculate_shoaling_cof(t, L, d)

            # Generate and save the Shoaling Coefficient plot
            depths = np.linspace(0.1, 10, 100)
            shoaling_coefficients = [calculate_shoaling_cof(t, L, dep) for dep in depths]
            plt.plot(depths, shoaling_coefficients)
            plt.xlabel('Water Depth (m)')
            plt.ylabel('Shoaling Coefficient (Ks)')
            plt.title('Shoaling Coefficient vs. Water Depth')
            plt.grid(True)
            shoaling_plot_path = os.path.join(app.root_path, 'static', 'shoaling_coefficient_plot.png')
            plt.savefig(shoaling_plot_path)
            plt.close()

            # Generate and save the Height vs Water Depth plot
            heights = [calculate_shoaling_cof(t, L, dep) * H0 for dep in depths]
            plt.plot(depths, heights)
            plt.xlabel('Water Depth (m)')
            plt.ylabel('Height of Water Wave')
            plt.title('Height of Wave vs. Water Depth')
            plt.grid(True)
            height_plot_path = os.path.join(app.root_path, 'static', 'height_vs_depth.png')
            plt.savefig(height_plot_path)
            plt.close()

            # Convert alpha0 to radians for the refraction calculation
            alpha0 = np.radians(alpha0)

            # Function to calculate refraction coefficient
            def calculate_refraction_cof(alpha0, C0, T):
                alpha = np.arcsin(C0 * np.sin(alpha0) / (g * T / (2 * math.pi)))
                Kr = np.sqrt(np.cos(alpha0) / np.cos(alpha))
                return Kr

            # Generate and save the Refraction Coefficient plot
            alpha0_degrees = np.linspace(0, 90, 100)
            alpha0_radians = np.radians(alpha0_degrees)
            refraction_coefficients = [calculate_refraction_cof(alpha, g * t / (2 * math.pi), t) for alpha in alpha0_radians]
            plt.plot(alpha0_degrees, refraction_coefficients)
            plt.xlabel('Angle α0 (degrees)')
            plt.ylabel('Refraction Coefficient (Kr)')
            plt.title('Refraction Coefficient vs. Angle')
            plt.grid(True)
            refraction_plot_path = os.path.join(app.root_path, 'static', 'refraction_coefficient_plot.png')
            plt.savefig(refraction_plot_path)
            plt.close()

            result = {
                "shoaling_coefficient": Ks,
                "refraction_coefficient": refraction_coefficients[-1]  # Example: Get the last value or adjust as needed
            }

        except Exception as e:
            result = {
                "error": str(e)
            }

    return render_template('trans.html', 
                           result=result, 
                           shoaling_plot_path='/static/shoaling_coefficient_plot.png', 
                           height_plot_path='/static/height_vs_depth.png', 
                           refraction_plot_path='/static/refraction_coefficient_plot.png')

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5003)